import React from "react";
import { View, Text, TouchableOpacity } from 'react-native'
import { Child1 } from "../../shared/components/child1";
import { styles } from "./parent.styles";


export const ParentStory = (props) => {
    const {
        value,
        gotoParent2
    } = props
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Parent</Text>
            <Child1 value={value} />
            <TouchableOpacity onPress={gotoParent2}>
                <Text>Go to Parent 2</Text>
            </TouchableOpacity>
        </View>
    )
}