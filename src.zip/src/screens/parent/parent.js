import React, { createContext, useState } from "react";
import { ParentStory } from './parentStory'

export const Global = createContext()
export const Parent = (props) => {
    const {
        navigation
    } = props
    const [email, setEmail] = useState('')

    const gotoParent2 = () => {
        navigation.navigate('Parent2')
    }
    return (
        <Global.Provider
            value={{
                contextValue: "contextVal",
                setEmail: () => setEmail(),
                email: email
            }}
        >
            <ParentStory
                value={'props val'}
                gotoParent2={gotoParent2}
            />
        </Global.Provider>
    )
}