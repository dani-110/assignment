import React from "react";
import { ParentStory2 } from './parentStory2'

export const Parent2 = (props) => {
    const {
        navigation
    } = props
    const gotoParent3 = () => {
        navigation.navigate('Parent3')
    }
    return (
        <ParentStory2
            gotoParent3={gotoParent3}
        />
    )
}