import React from "react";
import { View, Text, TouchableOpacity } from 'react-native'
import { styles } from "./parent2.styles";


export const ParentStory2 = (props) => {
    const {
        gotoParent3
    } = props
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Parent 2</Text>
            <TouchableOpacity onPress={gotoParent3}>
                <Text>Go to Parent 3</Text>
            </TouchableOpacity>
        </View>
    )
}