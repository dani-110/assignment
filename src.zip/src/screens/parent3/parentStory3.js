import React from "react";
import { TouchableOpacity } from "react-native";
import { View, Text } from 'react-native'
import { styles } from "./parent3.styles";


export const ParentStory3 = (props) => {
    const {
        goback
    } = props
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Parent 3</Text>
            <TouchableOpacity onPress={goback}>
                <Text>Go Back</Text>
            </TouchableOpacity>
        </View>
    )
}