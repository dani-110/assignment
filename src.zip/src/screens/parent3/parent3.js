import React from "react";
import { ParentStory3 } from './parentStory3'

export const Parent3 = (props) => {
    const {
        navigation
    } = props
    const goback = () => {
        navigation.goBack()
    }
    return (
        <ParentStory3
            goback={goback}
        />
    )
}