import React, { useContext } from 'react'
import { View, Text } from 'react-native'
import { Global } from '../../screens/parent/parent'
import { styles } from './style'

export const Child3 = (props) => {

    const {
        contextValue
    } = useContext(Global)
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Child 3</Text>
            <Text>{contextValue}</Text>
        </View>
    )
}