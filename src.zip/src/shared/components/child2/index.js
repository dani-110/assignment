import React, { useContext } from 'react'
import { View, Text, TextInput } from 'react-native'
import { Global } from '../../../screens/parent/parent'
import { Child3 } from '../child3'
import { styles } from './style'

export const Child2 = (props) => {
    const {
        value
    } = props

    const {
        contextValue,
        setEmail
    } = useContext(Global)
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Child 2</Text>
            <Text>{value}</Text>
            <TextInput
                style={{ borderWidth: 1, width: 200 }}
                onChangeText={(e) => setEmail(e)}
            />
            <Text>{contextValue}</Text>
            <Child3 />
        </View>
    )
}