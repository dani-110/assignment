import React from 'react'
import { View, Text } from 'react-native'
import { Child2 } from '../child2'
import { styles } from './style'

export const Child1 = (props) => {

    const {
        value
    } = props
    return (
        <View style={styles.mainContainer}>
            <Text style={styles.textUI}>Child 1</Text>
            <Child2 value={value} />
        </View>
    )
}